package com.example.weatherdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherDashboardApplication {
    public static void main(String[] args) {
        SpringApplication.run(WeatherDashboardApplication.class, args);
    }
}